package shoppingcart;

public class Calculator {

	 int add(int x, int y)
	{
		// TODO Auto-generated method stub
		int temp=x+y;
		
		return temp;
	}
	 
	 int sub(int x1, int y1)
	{
		// TODO Auto-generated method stub
		int temp=x1-y1;
		
		return temp;
	}
	 
	 int mul(int x2, int y2)
	{
		// TODO Auto-generated method stub
		int temp=x2*y2;
		
		return temp;
	}
	 
	 int div(int x3, int y3)
	{
		// TODO Auto-generated method stub
		int temp=x3/y3;
		
		return temp;
	}

}
