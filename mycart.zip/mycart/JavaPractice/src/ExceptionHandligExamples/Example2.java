package ExceptionHandligExamples;

public class Example2 {

}
