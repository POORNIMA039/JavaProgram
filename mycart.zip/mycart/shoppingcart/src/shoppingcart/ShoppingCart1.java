package shoppingcart;

public class ShoppingCart1 {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		String customerName="James";
		String itemDescription="shirt";
		int quantity=3;
		int price=40;
		boolean stockStatus;
		double total;
		double tax=1.05;
		
		String message = customerName + " " + "wants to buy" + " " + quantity + " " + itemDescription;
		
		if(quantity>1);
		{
			message=message + "s";
		}
		
		total=(price*quantity)*tax;
		
		stockStatus=true;
		
		if(stockStatus)
		{
			System.out.println("IN STOCK");
		}
		else
		{
			System.out.println("OUT OF STOCK");
		}
		
		System.out.println(message);
		System.out.println("TOTAL: "+total);

	}

}
