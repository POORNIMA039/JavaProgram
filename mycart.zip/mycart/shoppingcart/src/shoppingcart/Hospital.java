package shoppingcart;

public class Hospital
{
	private String name;
	private int age;
	
	Hospital(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	
	/*Hospital()
	{
		
	}*/

	 String getName()
	{
		return name;
	}

	 int getAge() 
	{
		return age;
	}

}
