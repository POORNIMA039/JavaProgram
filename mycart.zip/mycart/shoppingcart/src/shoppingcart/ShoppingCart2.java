package shoppingcart;
//overloading constructors example
public class ShoppingCart2 {

	public static void main(String[] args)
	{
      Customer customer1 = new Customer("Smith","@@@@@@!A");
      Customer customer2 = new Customer("Robert","****1");
      Customer customer3 = new Customer("James","****aa");
      Customer customer4 = new Customer("Mickel","****vvvv");
      
      System.out.print("Customer Name:" + " " + customer1.getName()+"&& ");
     System.out.println	("Social Security Number: " + " " + customer1.getSsn());
     
     System.out.print("Customer Name:" + " " + customer2.getName()+" &&");
     System.out.println	("Social Security Number: " + " " + customer2.getSsn());
     
     System.out.print("Customer Name:" + " " + customer3.getName()+" &&");    
     System.out.println	("Social Security Number: " + " " + customer3.getSsn());
     
     System.out.print("Customer Name:" + " " + customer4.getName()+" &&");    
     System.out.println	("Social Security Number: " + " " + customer4.getSsn());
	}

}
