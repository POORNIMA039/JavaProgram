import java.util.Scanner;
public class Example5{
     public static void main(String[] args) {
    	 //product of two numbers
    	 int input_first_number,input_second_number;
    	 int result;
    	 Scanner s = new Scanner(System.in);
    	 System.out.println("Enter two numbers");
    	 input_first_number=s.nextInt();
    	 input_second_number=s.nextInt();
    	 System.out.println("input_first_number :"+input_first_number);
    	 System.out.println("input_second_number :"+input_second_number);
    	 result=input_first_number*input_second_number;
    	 System.out.println("Product result :"+result);
     }}
