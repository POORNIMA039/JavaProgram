package shoppingcart;

public class LaunchHospital 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
      Hospital h = new Hospital("raju", 59);
   // Hospital h = new Hospital();
        
        System.out.println("NAME OF THE PATIENT:" + " " + h.getName());
        System.out.println("AGE OF THE PATIENT:" + " " + h.getAge());
		
	}

}
