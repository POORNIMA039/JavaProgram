package mycart;

public class MyCart {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
      System.out.println("WELCOME TO MyCart");
	}

}
